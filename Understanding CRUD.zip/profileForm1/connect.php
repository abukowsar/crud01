<?php
    $con=mysqli_connect("localhost","root","","students") or die("Error: ".mysqli_error($con));
?>